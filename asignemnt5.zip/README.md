⚠️ Deviation from Assignment Instructions
While implementing /pages/artwork.js, I followed the assignment requirements strictly:

Used useSWR to fetch data from the Met API using the q query param

Paginated the results into a 2D array using useEffect

Returned <Error statusCode={404} /> when appropriate

However, I encountered a runtime error during testing the site reloads:

Error: Rendered more hooks than during the previous render.
This would happen inconsistently (e.g., on the 6th or 7th refresh), even though the code passed all assignment logic and tests on first load.

Root Cause
This issue arises from how React handles hooks execution order:

React requires all hooks (useState, useEffect, useSWR, etc.) to run unconditionally and in the same order on every render.

The assignment solution suggested checking for router.query.q or !data before hooks (via return null;) — this conditionally prevents hooks from running, which breaks React’s rules.

When a page is refreshed, Next.js hydrates the client with a mismatched hook tree, causing a crash.

✅ Fix Applied (and Why)
To resolve this:

I moved all hooks to the top of the component (before any if checks or return)

I replaced return null with a lightweight fallback UI like <div>Loading...</div>

This ensures all hooks always run, satisfying React’s hook rules

The logic still fully aligns with the assignment in terms of data handling, pagination, and SWR usage

Summary
I consulted ChatGPT to debug this issue.
The solution required diverging slightly from the assignment's suggested structure to make the code stable and React-compliant.
The overall app behavior, features, and logic remain fully aligned with the assignment goals.
